# MoviesNShows
This app provides you necessary information of movies and TV Series.
